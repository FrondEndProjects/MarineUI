import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import * as Mydatas from '../../../../../app-config.json';
import { NbComponentStatus, NbGlobalPhysicalPosition, NbToastrService } from '@nebular/theme';
import { MastersService } from '../../masters.service';

@Component({
  selector: 'app-transport-app-edit',
  templateUrl: './transport-app-edit.component.html',
  styleUrls: ['./transport-app-edit.component.scss']
})
export class TransportAppEditComponent implements OnInit {

  public transportForm: FormGroup;
  public countryList = [];
  
  public AppConfig: any = (Mydatas as any).default;
  public ApiUrl1: any = this.AppConfig.ApiUrl1;
  public editBankId: any; bankId: any;
  public Userdetails: any;
  public branchCode: any; 
  public transportId; DisplayOrder; transportDetails;

  constructor( private router: Router,
    private masterSer: MastersService,
    private toastrService: NbToastrService ) {

    this.Userdetails = JSON.parse(sessionStorage.getItem('Userdetails'));
    
    if(this.Userdetails) {
      this.branchCode = this.Userdetails?.LoginResponse?.BranchCode;
    }

    this.transportId = JSON.parse(sessionStorage.getItem('transportData'));
    if(this.transportId) {
      this.getTransportDetails();
    } else {
      this.transportId = null;
    }
  }
  
  ngOnInit(): void {
    this.createForm();
    
  }

  getTransportDetails() {
    let ReqObj = {
      "BranchCode": this.branchCode,
      "ModeOfTransportId": this.transportId
    }
    
    this.masterSer.onPostMethodSync(`${this.ApiUrl1}master/modeOfTransportMaster/edit`, ReqObj).subscribe(
      (data: any) => {
        console.log(data);
        
        this.transportDetails = data.Result;
        this.DisplayOrder = this.transportDetails.DisplayOrder;
        this.transportForm.controls['modeOfTransport'].setValue(this.transportDetails.ModeOfTransportDesc)
        this.transportForm.controls['coreApplicationCode'].setValue(this.transportDetails.CoreApplicationCode)
        this.transportForm.controls['remarks'].setValue(this.transportDetails.Remarks)
        this.transportForm.controls['status'].setValue(this.transportDetails.Status)
      }, (err) => { }
    )
  }


  public createForm() {

    this.transportForm = new FormGroup({
      modeOfTransport : new FormControl( '', Validators.required),
      coreApplicationCode : new FormControl( '', Validators.required),
      remarks : new FormControl(''),
      status : new FormControl('Y', Validators.required)
    });
  }

  public goBack() {
    this.router.navigateByUrl('/Marine/masters/transport/view');
  }

  onSave() {
    let ReqObj = {
      "BranchCode": this.branchCode,
      "CoreApplicationCode": this.transportForm.controls['coreApplicationCode'].value,
      "DisplayOrder": this.DisplayOrder,
      "ModeOfTransportDesc": this.transportForm.controls['modeOfTransport'].value,
      "ModeOfTransportId": this.transportId,
      "Remarks": this.transportForm.controls['remarks'].value,
      "Status": this.transportForm.controls['status'].value,
    }
    console.log(ReqObj);
    
    this.masterSer.onPostMethodSync(`${this.ApiUrl1}master/modeOfTransportMaster/save`, ReqObj).subscribe(
      (data: any) => {
        console.log(data);

        if(data.Message == 'Success') {

          let type: NbComponentStatus = 'success';
          const config = {
            status: type,
            destroyByClick: true,
            duration: 4000,
            hasIcon: true,
            position: NbGlobalPhysicalPosition.TOP_RIGHT,
            preventDuplicates: false,
          };
          this.toastrService.show(
            'Mode of Transport Details Inserted/Updated Successfully',
            'Mode of Transport Details',
            config);

            sessionStorage.removeItem('transportData');
            this.router.navigateByUrl('Marine/masters/transport/view')
        }
        else if (data.Errors) {
          for (let entry of data.Errors) {
            let type: NbComponentStatus = 'danger';
            const config = {
              status: type,
              destroyByClick: true,
              duration: 4000,
              hasIcon: true,
              position: NbGlobalPhysicalPosition.TOP_RIGHT,
              preventDuplicates: false,
            };
            this.toastrService.show(
              entry.Field,
              entry.Message,
              config);
          }
          //this.loginService.errorService(data.ErrorMessage);
        }
        
        if(data.Message == 'Success') {
         
        }
      }, (err) => { }
    )

  }

}
