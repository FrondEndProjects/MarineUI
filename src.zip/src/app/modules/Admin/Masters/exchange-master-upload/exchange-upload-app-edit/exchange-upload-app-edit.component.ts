import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-exchange-upload-app-edit',
  templateUrl: './exchange-upload-app-edit.component.html',
  styleUrls: ['./exchange-upload-app-edit.component.scss']
})
export class ExchangeUploadAppEditComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
