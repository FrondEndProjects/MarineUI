import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-exchange-upload-table',
  templateUrl: './exchange-upload-table.component.html',
  styleUrls: ['./exchange-upload-table.component.scss']
})
export class ExchangeUploadTableComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
