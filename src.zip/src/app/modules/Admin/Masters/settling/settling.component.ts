import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-settling',
  templateUrl: './settling.component.html',
  styleUrls: ['./settling.component.scss']
})
export class SettlingComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
