import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-setting-agent-app-edit',
  templateUrl: './setting-agent-app-edit.component.html',
  styleUrls: ['./setting-agent-app-edit.component.scss']
})
export class SettingAgentAppEditComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
