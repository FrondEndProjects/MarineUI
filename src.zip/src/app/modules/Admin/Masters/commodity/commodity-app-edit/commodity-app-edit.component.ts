import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import * as Mydatas from '../../../../../app-config.json';
import { MastersService } from '../../masters.service';

@Component({
  selector: 'app-commodity-app-edit',
  templateUrl: './commodity-app-edit.component.html',
  styleUrls: ['./commodity-app-edit.component.scss']
})
export class CommodityAppEditComponent implements OnInit {

  public commodityForm: FormGroup;
  public transportList = [];
  public coverList = [];
  public commodityId;
  public AppConfig: any = (Mydatas as any).default;
  public ApiUrl1: any = this.AppConfig.ApiUrl1;
  public userDetails: any;
  public branchCode: any;
  public minDate:any;
  form:any;
  properties:any[]=[];
  objectKeys = Object.keys;
  clauses:any[]=[];
  Deductible1="N";

  constructor( private router: Router,
     private route: ActivatedRoute,
     private masterSer: MastersService ) {
      this.minDate = new Date();
    this.userDetails = JSON.parse(sessionStorage.getItem('Userdetails'));
    if (this.userDetails) this.branchCode = this.userDetails?.LoginResponse?.BranchCode;

    let commodityData = JSON.parse(sessionStorage.getItem('commodityData'));

    if ( commodityData) {
      this.commodityId = commodityData
    }
  }

  ngOnInit(): void {
    this.getCommodityEdit();
    this.createForm();
  }

  checkUWValue(value) {
    return value = "N";
  }

  getCommodityEdit() {
    let ReqObj = {
      "CommodityId": this.commodityId
    }
    this.masterSer.onPostMethodSync(`${this.ApiUrl1}master/commodity/edit`, ReqObj).subscribe(
      (data: any) => {
        console.log(data);

        let commodityForm = data.Result;
        this.form =data.Result;

        //this.commodityForm.controls['ModeOfTransportId'].setValue(commodityForm.ModeOfTransportId);
        this.commodityForm.controls['CommodityName'].setValue(commodityForm.CommodityName);
        this.commodityForm.controls['CommodityRate'].setValue(commodityForm.CommodityRate);
        this.commodityForm.controls['CoreApplicationCode'].setValue(commodityForm.CoreApplicationCode);
        this.commodityForm.controls['effectiveDate'].setValue(this.onDateFormatInEdit(commodityForm.EffectiveDate));
        this.commodityForm.controls['remarks'].setValue(commodityForm.Remarks);
        this.commodityForm.controls['status'].setValue(commodityForm.Status);


        this.clauses= data.Result.AllRisksLandTransitLandInfo.ClausesInfo


        //const result = commodityForm.map(item => Object.keys(item)[0]);

        //console.log(result);

        //this.properties=JSON.parse(commodityForm);
           //let response = Object.keys(this.properties);
           //console.log('TTTTTTT',response)

           const deleteFalsyKey = obj  => {
            const keys = Object.keys(this.form);
            keys.forEach(key => {
               if(obj[key].enabled === false){
                  delete obj[key];
                  return;
               };
               if(obj[key] && typeof obj[key] === 'object'){
                  deleteFalsyKey(obj[key]);
                  if (!Object.keys(obj[key]).length) {
                     delete obj[key];
                  };
               }
            });
         };


      }
    )
  }

  onDateFormatInEdit(date) {
    if (date) {
      let format = date.split('-');
      if (format.length > 1) {
        var NewDate = new Date(new Date(format[0], format[1], format[2]));
        NewDate.setMonth(NewDate.getMonth() - 1);
        return NewDate;
      }
      else {
        format = date.split('/');
        if (format.length > 1) {
          var NewDate = new Date(new Date(format[2], format[1], format[0]));
          NewDate.setMonth(NewDate.getMonth() - 1);
          return NewDate;
        }
      }
    }
  }

  public createForm() {

    this.commodityForm = new FormGroup({
      CommodityName: new FormControl('', Validators.required),
      CommodityRate : new FormControl( '', Validators.required),
      CoreApplicationCode : new FormControl( '', Validators.required),
      remarks : new FormControl( '', Validators.required),
      commodityExcessRate : new FormControl('', Validators.required),
      effectiveDate : new FormControl( '', Validators.required),
      status : new FormControl('Y'),
    });
  }

  public goBack() {
    this.router.navigateByUrl('/Marine/masters/commodity/view');
  }

  public onSave() {
  const ReqObj = {
      'BranchCode': this.branchCode,
        /*ConveyanName: this.commodityForm.get('conveyanceName').value,
        EffectiveDate: this.commodityForm.get('effectiveDate').value,
        ConveyanRate: this.commodityForm.get('conveyanceRate').value,
        CoreApplicationCode: this.commodityForm.get('coreApplicationCode').value,
        Remarks: this.commodityForm.get('remarks').value,
        Status: this.commodityForm.get('status').value,
        Mode : this.commodityForm.get('modeOfTransport').value,*/
        "CommodityName":this.commodityForm.controls['CommodityName'],
        "CommodityRate":this.commodityForm.controls['CommodityRate'],
        "CoreApplicationCode":this.commodityForm.controls['CoreApplicationCode'],
        "EffectiveDate":this.commodityForm.controls['effectiveDate'],
        "Remarks":this.commodityForm.controls['remarks'],
        "Status":this.commodityForm.controls['status']
    };
    /*this.masterSer.onPostMethodSync(`${this.ApiUrl1}master/extracover/save`, ReqObj).subscribe(
      (data: any) => {
        console.log(data);

        if (data.Message == 'Success') {

          let type: NbComponentStatus = 'success';
          const config = {
            status: type,
            destroyByClick: true,
            duration: 4000,
            hasIcon: true,
            position: NbGlobalPhysicalPosition.TOP_RIGHT,
            preventDuplicates: false,
          };
          this.toastrService.show(
            'Extra Cover Details Inserted/Updated Successfully',
            'Extra Cover Details',
            config);

          sessionStorage.removeItem('extraCoverData');
          this.router.navigateByUrl('/Marine/masters/extra-cover/view');
        }
        else if (data.Errors) {
          for (let entry of data.Errors) {
            let type: NbComponentStatus = 'danger';
            const config = {
              status: type,
              destroyByClick: true,
              duration: 4000,
              hasIcon: true,
              position: NbGlobalPhysicalPosition.TOP_RIGHT,
              preventDuplicates: false,
            };
            this.toastrService.show(
              entry.Field,
              entry.Message,
              config);
          }
          //this.loginService.errorService(data.ErrorMessage);
        }
      }
    )*/
    //const url = `${this.ApiUrl1}master/commodity/save,ReqObj)`;
    console.log(this.commodityForm.value);



    // this.conveyanceService.onPostMethodSync(`${this.ApiUrl1}master/conveyance/save`, ReqObj).subscribe({
    //   next(value) {

    //   },
    // });
  }


  // get transport list
  public getModeOFtransportList() {
    const ReqObj = {
      'BranchCode': this.branchCode,
      ProductId : '03',
      OpenCoverNo : '',
    };

    this.masterSer.onPostMethodSync(`${this.ApiUrl1}quote/dropdown/modeoftransport`, ReqObj).subscribe(
      (data: any) => {
        if (data?.Message === 'Success') {
          this.transportList = data.Result;
        }
      },
      (err) => { },
    );
  }

}
