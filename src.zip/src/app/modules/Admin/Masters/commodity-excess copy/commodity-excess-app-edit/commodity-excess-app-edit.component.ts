import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-commodity-excess-app-edit',
  templateUrl: './commodity-excess-app-edit.component.html',
  styleUrls: ['./commodity-excess-app-edit.component.scss']
})
export class CommodityExcessAppEditComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
