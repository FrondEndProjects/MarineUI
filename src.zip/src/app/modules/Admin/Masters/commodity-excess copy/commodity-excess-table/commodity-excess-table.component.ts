import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-commodity-excess-table',
  templateUrl: './commodity-excess-table.component.html',
  styleUrls: ['./commodity-excess-table.component.scss']
})
export class CommodityExcessTableComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
