
export class Issuer{

    "AttachedBranchInfo": [
      {
        "AttachedBranchId": null;
      }
    ];
    "AttachedRegionInfo": [
      {
        "RegionCode": null;
      }
    ];
    "BranchCode": null;
    "BrokerLinkLocation": null;
    "CoreLoginId": null;
    "EffectiveDate": any;
    "EmailId": null;
    "IssuerName": null;
    "LoginId": null;
    "LoginUserType":null;
    "OptionMode": null;
    "Password": null;
    "ProductInfo": [
      {
        "ProductId": null;
      }
    ];
    "RegionCode": null;
    "Status": null;
  }
