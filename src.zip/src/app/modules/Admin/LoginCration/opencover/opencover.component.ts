
import { Component, OnInit, Input, Inject } from '@angular/core';
import { MatDialogRef, MatDialog } from '@angular/material/dialog';
import {MAT_DIALOG_DATA} from '@angular/material/dialog';
@Component({
  selector: 'app-opencover-details',
  templateUrl: './opencover.component.html',
  styleUrls: ['./opencover.component.scss']
})
export class OpenCoverDocument implements OnInit {
  


    List:any;
    PolicyHeader:any[]=[];
    imageUrl:any;
   constructor( public dialogRef: MatDialogRef<OpenCoverDocument>,public dialog: MatDialog, @Inject(MAT_DIALOG_DATA) public data: any) {
    this.PolicyHeader =  [
        { key: 'Sno', display: 'Sno' },
        { key: 'OpenCoverNo', display: 'Open CoverNo' },
        { key: 'CompanyName', display: 'Customer Name' },
        {key:"MissippiOpenCoverNo",display:'MISSIPPI OPENCOVER NO'}

       
      ];
    }
 
   ngOnInit(): void {
    this.List = this.data.list;
    console.log('hhhhhhhhhh',this.List)
   }
   close(){ this.dialogRef.close();}
 }
