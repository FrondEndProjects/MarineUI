import { Component, OnInit,EventEmitter } from '@angular/core';
import {Router} from '@angular/router';
import * as Mydatas from '../../../../../app-config.json';
import { MastersService } from '../../../Masters/masters.service';
import { FormGroup } from '@angular/forms';
import { DatePipe } from '@angular/common';
import { NbComponentStatus, NbGlobalPhysicalPosition, NbToastrService } from '@nebular/theme';

import { AdminReferralService } from '../../../../admin-referral/admin-referral.service';
import { User } from './UserModel';
import { OpenCoverDocument } from '../../opencover/opencover.component';
import { LoginService } from '../../../../login/login.service';
import {
  MatDialog,
  MAT_DIALOG_DATA,
  MatDialogRef,
} from '@angular/material/dialog';
@Component({
  selector: 'app-new-user-details',
  templateUrl: './new-user-details.component.html',
  styleUrls: ['./new-user-details.component.scss']
})
export class NewUserDetailsComponent implements OnInit {
  btnNextPrev = {
    prev: true,
    next: false,
    index: 0
  }
  StatusList:any[]=[];
  value:any="View";
  Status:any;
  BrokerName:any;
  userType:any[]=[];
  public AppConfig: any = (Mydatas as any).default;
  public ApiUrl1: any = this.AppConfig.ApiUrl1;
  BranchCode: any;
  LoginId: any;
  UserDetails:any;
  branchList:any[]=[];
  TitleList:any[]=[];
  Title:any;
  FirstName:any;
  LastName:any;
  Gender:any;
  DateOfBirth:any;
  Occupation:any;
  countryList:any[]=[];
  CityList:any[]=[];
  Country: any;
  Pobox:any;
  TelephoneNo:any;
  Address1:any;
  Address2:any;
  Mobile:any;
  Fax:any;
  Email:any;
  AttachedBranch:any;
  AttachedRegion:any;
  Password:any;
  RePassword:any;
  City:any;
  AgencyCode:any;
  brokerType:any[]=[];
  open: boolean;
  AgentCode: any;
  UserAgentCode: any;
  CustomerId: any;
  ProductInfo:any[]=[];
  EPassword: any;
  NPassword: any;
  productNameList:any[]=[];
  ProductInfos:any[]=[];
  Iss: boolean;
  List:any[]=[];
  onActive= new EventEmitter();
  ProList:any[]=[];
  pass:any;
  regionList :any[]=[];
  AttachedBranchList:any[]=[];
  NationalityList:any[]=[];
  

  constructor(private masterSer: MastersService,private datePipe:DatePipe,
    private toastrService:NbToastrService, private router:Router, private adminReferralService: AdminReferralService,public dialog: MatDialog, private loginService: LoginService) {
      this.StatusList=[{"Code":"Y","CodeDesc":"Active"},
      {"Code":"N","CodeDesc":"DeActive"},
      {"Code":"D","CodeDesc":"Delete"},
      {"Code":"T","CodeDesc":"Lock"},
  ];
 
  this.UserDetails=new User();


  this.ProductInfo= [{
    "InsuranceEndLimit": "500000000",
    "PayReceipt": "",
    "ProductId": "3",
    "ProductName": "MARINE CARGO INDIVIDUAL POLICY",
    "ProductYN": "Y",
    "SpecialDiscount": "0.0",
    "UserFreight": "N"
  },
  {
    "InsuranceEndLimit": "",
    "PayReceipt": "",
    "ProductId": "11",
    "ProductName": "MARINE CARGO - OPEN COVER",
    "ProductYN": "",
    "SpecialDiscount": "",
    "UserFreight": "N"
  },
]

/*this.ProductInfos=[
  {
    "InsuranceEndLimit": "",
    "PayReceipt": "",
    "ProductId": "11",
    "ProductName": "MARINE CARGO - OPEN COVER",
    "ProductYN": "",
    "SpecialDiscount": "",
    "UserFreight": "N"
  },
]*/

     }

  ngOnInit(): void {


    let AdminObj = JSON.parse(sessionStorage.getItem('editUserId'));
    //let password =sessionStorage.removeItem("password");
    //let password=sessionStorage.getItem('password');
     this.BranchCode = AdminObj?.BranchCode;
     this.LoginId = AdminObj.LoginId;
     this.AgencyCode=AdminObj.AgencyCode;

     if(this.AgencyCode!=null && this.AgencyCode!=undefined){
      this.getEditAdminDetails();
      //this.editSection=false;


    }
    else{
      this.UserDetails = new User();
      this.pass=true;
      // this.BranchCode = IssuerObj.BranchCode;
      // this.IssuerDetails.LoginId = IssuerObj.LoginId;
      // this.editdata=true;
      //if(this.CityDetails?.Status==null)  this.CityDetails.Status = 'Y';
    }
    //this.getCountryList()
    this.onUserType();
    this.getUserAll();
    //this.getTitle();
    this.getBroker();
    this.onGetProductList();
    this.onGetRegionList();



  }


  ProductComma(){
    var str = this.UserDetails.AttachedRegion;
  this.UserDetails.AttachedRegion= str.split(',');
  this.UserDetails.AttachedRegion = this.UserDetails.AttachedRegion.filter(item => item);
    console.log('BBB',this.UserDetails.AttachedRegion)
  }
  Branchf(){
    var str = this.UserDetails.AttachedBranch;
  this.UserDetails.AttachedBranch= str.split(',');
  this.UserDetails.AttachedBranch = this.UserDetails.AttachedBranch.filter(item => item);
    console.log('BBB',this.UserDetails.AttachedBranch)
  }

  onGetRegionList() {
    const urlLink = `${this.ApiUrl1}admin/region/list`;
    this.loginService.onGetMethodSync(urlLink).subscribe((data: any) => {
      console.log(data);
      this.regionList = data?.Result;

    });
  }
  regions(){
    let RegionList= [];
    if(this.UserDetails.AttachedRegion.length!=0){
      let i=0;
        for(let u of this.UserDetails.AttachedRegion){      
        let entryRegion={"RegionCode":u}    
        RegionList.push(entryRegion);
        i++;
        if(i==this.UserDetails.AttachedRegion.length) this.AttachedBranches(RegionList);
      }
    
    }
    else this.AttachedBranches(RegionList)
  }

  AttachedBranches(uwList){
    let ReqObj = 
    {
      "AgencyCode": this.AgencyCode,
    "RegionCodeInfo":uwList
  }
    this.masterSer.onPostMethodSync(`${this.ApiUrl1}admin/getAttachedBranchDetails`, ReqObj).subscribe(
      (data: any) => {
        console.log('ssssssss',data);
        this.AttachedBranchList= data || [];
      }
    )
  
  }
  onActiveDetails(rowData){

    console.log('hhhhh',rowData)
    this.ProList=rowData
    console.log('jjjjjjj',this.ProList)
  }


Open(){

  let ReqObj = {
"AgencyCode":this.AgencyCode,
"UAgencyCode":this.AgencyCode
  }
  this.masterSer.onPostMethodSync(`${this.ApiUrl1}admin/getUserMgtOCCertificate`, ReqObj).subscribe(
    (data: any) => {
      console.log(data);
          
      this.List=data.Result;
      if (data.Message == 'Success') {
        const dialogRef = this.dialog.open(OpenCoverDocument, {

          data: {
         list:data.Result
          }
        });
        dialogRef.afterClosed().subscribe((result) => {
         
        });
       
      }
    }
  ) 
  
}


  onRedirect(value){
    this.value=value;
    if(value == 'View'){
  
    }
    else if(value == 'ChangePassword'){
      this.Iss=false;
    }
  
  
  }
  getEditAdminDetails(){

    let ReqObj =  {
      "AgencyCode": this.AgencyCode,
      "UAgencyCode": "1"

  }
    let urlLink = `${this.ApiUrl1}admin/getUserMgtEditList`;
  this.masterSer.onPostMethodSync(urlLink, ReqObj).subscribe(
    (data: any) => {
      console.log(data);
      let res:any = data;
      if(res.Result){
        this.UserDetails = res.Result[0];
        this.Status=res.Result[0].Status
                this.Iss=true;
                this.getBroker();
                this.onUserType();
                //this.getCountryList();
                this.ProductComma();
                this. AttachedBranches(this.UserDetails.AttachedRegion)
                this.Branchf();

                
                this.AgencyCode=res.Result[0].AgencyCode


        if(this.UserDetails){
          if(this.UserDetails?.DateOfBirth!=null){

           this.UserDetails.DateOfBirth = this.onDateFormatInEdit(this.UserDetails?.DateOfBirth)
          }
          /*if(this.AdminDetails?.EffectiveDateEnd!=null){
            this.AdminDetails.EffectiveDateEnd = this.onDateFormatInEdit(this.AdminDetails?.EffectiveDateEnd)
          }*/
          this.onGetBranchList();

        }
      }
      console.log("Final Admin Class",this.UserDetails);
    },
    (err) => { },
  );
  }


 Atregion(){

  console.log('hhhhhhhhhh')
    let RegionList= [];
    if(this.UserDetails.AttachedRegion.length!=0){
      let i=0;
        for(let u of this.UserDetails.AttachedRegion){      
        let entryRegion={"RegionCode":u}    
        RegionList.push(entryRegion);
        i++;
        if(i==this.UserDetails.AttachedRegion.length) this.AttachedBranchFinal(RegionList);
      }
    
    }
    else this.AttachedBranchFinal(RegionList)
  }

  AttachedBranchFinal(RegionList){
    let BranchList= [];
    if(this.UserDetails.AttachedBranch.length!=0){
      let i=0;
        for(let u of this.UserDetails.AttachedBranch){      
        let entryRegion={"AttachedBranchId":u}    
        BranchList.push(entryRegion);
        i++;
        if(i==this.UserDetails.AttachedBranch.length) this.onSave(RegionList,BranchList);
      }
    
    }
    else this.onSave(RegionList,BranchList)
  }
  
  onGetBranchList() {
    const urlLink = `${this.ApiUrl1}login/getBranchDetail`;
    const reqData = {
      'RegionCode': '01',
    };
    this.adminReferralService.onPostMethodSync(urlLink, reqData).subscribe(
      (data: any) => {
        console.log(data);
        this.branchList = data || [];
        //this.onGetRegionList();
      },
      (err) => { },
    );
  }

  getBroker() {
    let ReqObj = {
      "BranchCode": this.BranchCode,
      "ApplicationId": "2",
    }
    this.masterSer.onPostMethodSync(`${this.ApiUrl1}admin/getAdminBrokerList`, ReqObj).subscribe(
      (data: any) => {
        console.log(data);

        if (data.Message == 'Success') {
          this.brokerType= data.Result;
        }
      }
    )

  }


  getUserAll(){
    let ReqObj={
        "BranchCode": this.BranchCode
    }
    this.masterSer.onPostMethodSync(`${this.ApiUrl1}admin/getUserMgtDropDown`, ReqObj).subscribe(
      (data: any) => {
        console.log(data);

        if (data.Message == 'Success') {
          this.countryList = data.Result.CountryDetails;
          this.CityList=data.Result.CityDetails;
          this.NationalityList=data.Result.NationalityDetails;
          this.TitleList=data.Result.TitleDetails;

          //this.city()
        }
      }
    )
  }


  /*getCountryList() {
    let ReqObj = {
      "BranchCode": this.BranchCode,
      "ProductId": "3"
    }
    this.masterSer.onPostMethodSync(`${this.ApiUrl1}quote/dropdown/originationcountry`, ReqObj).subscribe(
      (data: any) => {
        console.log(data);

        if (data.Message == 'Success') {
          this.countryList = data.Result;
          this.city()
        }
      }
    )

  }*/



  /*city(){


    let reqObj=
       {
        "OriginationCountryCode":this.UserDetails.Country
      }
      this.masterSer.onPostMethodSync(`${this.ApiUrl1}quote/dropdown/originationcity`, reqObj).subscribe(
        (data: any) => {
          console.log(data);

          if (data.Message == 'Success') {
            this.CityList = data.Result;
          }
        }


      )
  }*/
  goBack(){
    this.router.navigate(['/Marine/loginCreation/existingUser'])
  }

  Vback(){
    this.value='View'
  }
  onSave(RegionList,BranchList){

    let Agent:any
    if(this.AgencyCode){
    Agent=this.AgencyCode
    }
    else{
      Agent="";
    }


    /*if(this.UserDetails.UserId!=undefined && this.UserDetails.UserId!=null && this.UserDetails.UserId!=''){
      //let code = this.productItem
      let code = this.userType.find(ele=>ele.Code==this.UserDetails.UserId)
      console.log('codes',code)
      this.UserDetails.UserType=code.CodeDescription;
      //code.label

      //this.mobileCodeList.label = this.productItem.MobileCod['CodeDesc'];
     }*/


let ReqObj={

    "Address1": this.UserDetails.Address1,
    "Address2": this.UserDetails.Address2,
    "AgencyCode":this.AgencyCode ,
    "AttachedBranchInfo":BranchList,
    "AttachedRegionInfo":RegionList,
    "City":this.UserDetails.City,
    "Country": this.UserDetails.Country,
    "CustFirstName":this.UserDetails.FirstName,
    "CustLastName": this.UserDetails.LastName,
    "CustomerId": "",
    "DateOfBirth":this.UserDetails.DateOfBirth,
    "Email":this.UserDetails.Email,
    "Fax": this.UserDetails.Fax,
    "Gender": this.UserDetails.Gender,
    "LoginId": this.UserDetails.LoginId,
    "MobileNo": this.UserDetails.MobileNo,
    "Mode": this.UserDetails.Mode,
    "Nationality":this.UserDetails.Nationality,
    "Occupation": this.UserDetails.Occupation,
    "Password": this.UserDetails.Password,
    "PoBox": this.UserDetails.Pobox,
    "RePassword": this.UserDetails.RePassword,
    "Status": this.Status,
    "SubBranchCode":this.UserDetails.SubBranchCode,
    "TelephoneNo": this.UserDetails.TelephoneNo,
    "Title": this.UserDetails.Title,
    "UserAgencyCode": this.UserDetails.UserAgencyCode,
    "UserId": "1",
    "UserType": this.UserDetails.UserType
}
let urlLink = `${this.ApiUrl1}admin/UserMgtInsertOrUpdate`;

/*if (ReqObj.EffectiveDate != '' && ReqObj.EffectiveDate != null && ReqObj.EffectiveDate != undefined) {
  ReqObj['EffectiveDate'] =  this.datePipe.transform(ReqObj.EffectiveDate, "dd/MM/yyyy")
}
else{
  ReqObj['EffectiveDate'] = "";
}*/
if (ReqObj.DateOfBirth != '' && ReqObj.DateOfBirth != null && ReqObj.DateOfBirth != undefined) {
  ReqObj['DateOfBirth'] =  this.datePipe.transform(ReqObj.DateOfBirth, "dd/MM/yyyy")
}
else{
  ReqObj['DateOfBirth'] = "";
}


this.masterSer.onPostMethodSync(urlLink, ReqObj).subscribe(
(data: any) => {
    console.log(data);
    let res:any=data;
    if(data.Result){

      this.open=true;
      this.Iss=true;
      this.nav('next');
      //this.AgentCode=data.Result.AgencyCode;
      this.UserAgentCode=data.Result.UserAgencyCode;
      this.CustomerId=data.Result.CustomerId;
      
      //this.productInsert()
/*let type: NbComponentStatus = 'success';
            const config = {
              status: type,
              destroyByClick: true,
              duration: 4000,
              hasIcon: true,
              position: NbGlobalPhysicalPosition.TOP_RIGHT,
              preventDuplicates: false,
            };
            this.toastrService.show(
              'Issuer Details Inserted/Updated Successfully',
              'Issuer Details',
              config);*/
//this.router.navigate(['/Marine/loginCreation/issuer']);


    }
    else if(data.ErrorMessage){
        if(res.ErrorMessage){
          /*for(let entry of res.ErrorMessage){
            let type: NbComponentStatus = 'danger';
            const config = {
              status: type,
              destroyByClick: true,
              duration: 4000,
              hasIcon: true,
              position: NbGlobalPhysicalPosition.TOP_RIGHT,
              preventDuplicates: false,
            };
            this.toastrService.show(
              entry.Field,
              entry.Message,
              config);
          }*/
          console.log("Error Iterate",data.ErrorMessage)
          //this.loginService.errorService(data.ErrorMessage);
        }
    }
  },
  (err) => { },
);

  }
  onGetProductList() {
    const urlLink = `${this.ApiUrl1}opencover/dropdown/referral/quoteproduct`;
    const reqData = {
      "LoginId": this.LoginId,
     "BranchCode": this.BranchCode
    };
    this.adminReferralService.onPostMethodSync(urlLink, reqData).subscribe(
      (data: any) => {
        console.log(data);
        this.productNameList = data?.Result?.ProductionDetails || [];
      },
      (err) => { },
    );
  }
  productInsert(i){

   
    let ReqObj={
      
  "AgencyCode": this.AgencyCode,
  "CustomerId":  this.CustomerId,
  "CustomerName": "",
  "OpenCoverInfo":[{
    "OpenCover":""
  }],
  "ProductInfo":i, 
  "UserAgencyCode":this.UserAgentCode
    }

    this.masterSer.onPostMethodSync(`${this.ApiUrl1}admin/UserMgtProductInsert`, ReqObj).subscribe(
      (data: any) => {
        console.log(data);
        if(data.Result){

          this.router.navigate(['/Marine/loginCreation/existingUser'])

        }
       
      }

    )
  }

  checkUWValue(value) {
    return value = "N";
  }

  region(){

    console.log('HHHHHHHH')
    let RegionList= [];

    RegionList.push(this.ProList)
    this.productInsert(RegionList)
    console.log('NNNNNNNNNN',RegionList)

  }

  onUserType() {
    const urlLink = `${this.ApiUrl1}admin/getAdminUserTypeList`;
    const reqData = {
      "ApplicationId": "2",
      "BranchCode": this.BranchCode
    };
    this.adminReferralService.onPostMethodSync(urlLink, reqData).subscribe(
      (data: any) => {
        console.log(data);
        this.userType= data?.Result|| [];
      },
      (err) => { },
    );
  }
  nav(n) {
    switch (n) {
      case 'next': {
        this.btnNextPrev.index++
        if (this.btnNextPrev.index > 3) {
          this.btnNextPrev.prev = false
          this.btnNextPrev.next = true
        } else {
          this.btnNextPrev.prev = false
        }
      }; break;
      case 'prev': {
        this.btnNextPrev.index--
        if (this.btnNextPrev.index == 0) {
          this.btnNextPrev.prev = true
          this.btnNextPrev.next = false
        } else {
          this.btnNextPrev.next = false
        }
      }; break;

    }
  }

  onDateFormatInEdit(date) {
    console.log(date);
    if (date) {
      let format = date.split('-');
      if(format.length >1){
        var NewDate = new Date(new Date(format[0], format[1], format[2]));
        NewDate.setMonth(NewDate.getMonth() - 1);
        return NewDate;
      }
      else{
        format = date.split('/');
        if(format.length >1){
          var NewDate = new Date(new Date(format[2], format[1], format[0]));
          NewDate.setMonth(NewDate.getMonth() - 1);
          return NewDate;
        }
      }

    }
  }
  /*getTitle() {
    let ReqObj = {
      "BranchCode": this.BranchCode
    }
    this.masterSer.onPostMethodSync(`${this.ApiUrl1}quote/dropdown/title`, ReqObj).subscribe(
      (data: any) => {
        console.log(data);

        if (data.Message == 'Success') {
          this.TitleList = data.Result;
        }
      }
    )

  }*/


  ChangePassword(){
    const urlLink = `${this.ApiUrl1}admin/IssuerChangePassword`;
    const reqData = {
      "LoginId":this.LoginId,
     "Password": this.EPassword,
     "RePassword": this.NPassword
    };
    this.adminReferralService.onPostMethodSync(urlLink, reqData).subscribe(
      (data: any) => {
        console.log("Change Password Done Successfully");
       
      },
      (err) => { },
    );
  }

  onAddRow(){
    let entry = [{
      "InsuranceEndLimit": "",
      "PayReceipt": "",
      "ProductId": "11",
      "ProductName": "",
      "ProductYN": "",
      "SpecialDiscount": "",
      "UserFreight": ""
    }]
    this.ProductInfo = entry.concat(this.ProductInfo);
  }

}

 