export class User {
  
    "Address1": null;
    "Address2":  null;
    "AgencyCode":  null;
    "AttachedBranchInfo": [
      {
        "AttachedBranchId":  null;
      }
    ];
    "AttachedRegionInfo": [
      {
        "RegionCode":  null;
      }
    ];
    "City":  null;
    "Country":  null;
    "CustFirstName":  null;
    "CustLastName": null;
    "CustomerId":  null;
    "DateOfBirth":  any;
    "Email": null;
    "Fax": null;
    "Gender":  null;
    "LoginId": null;
    "MobileNo":  null;
    "Mode":  null;
    "Nationality":  null;
    "Occupation":  null;
    "Password":  null;
    "PoBox":  null;
    "RePassword":  null;
    "Status":  "Y";
    "SubBranchCode":  null;
    "TelephoneNo":  null;
    "Title":  null;
    "UserAgencyCode":  null;
    "UserId":  null;
    "UserType":  null;
  
}