import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-broker-details',
  templateUrl: './add-broker-details.component.html',
  styleUrls: ['./add-broker-details.component.scss']
})
export class AddBrokerDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
