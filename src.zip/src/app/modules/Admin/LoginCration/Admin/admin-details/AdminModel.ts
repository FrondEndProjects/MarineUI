/*export class Admin
{
  "Address1": null;
  "Address2":  null;
  "AgencyCode":  null;
  "Approvedby":  null;
  "AttachedBranchInfo": [
    {
      "AttachedBranchId":  null;
    }
  ];
  "AttachedRegionInfo": [
    {
      "RegionCode":  null;
    }
  ];
  "BorkerOrganization":  null;
  "BranchCode":  null;
  "BrokerCode":  null;
  "City":  null;
  "Country":  null;
  "CustFirstName":  null;
  "CustLastName":  null;
  "CustomerId":  null;
  "DateOfBirth":  null;
  "EffectiveDate":any;
  "Email":  null;
  "EmergencyFee":  null;
  "EmergencyFund": null;
  "Executive":  null;
  "Fax":  null;
  "Gender":  null;
  "GovetFee":  null;
  "GovtFeeStatus": null;
  "LoginId":  null;
  "MissippiId":  null;
  "MobileNo":  null;
  "Mode":  null;
  "Nationality":  null;
  "Occupation":  null;
  "OneOffCommission":  null;
  "OpenCoverCommission":  null;
  "Password":  null;
  "PoBox":  null;
  "PolicyFee":  null;
  "PolicyFeeStatus":  null;
  "RePassword":  null;
  "RegionCode":  null;
  "Status":  null;
  "SubBranchCode":  null;
  "TaxApplicable":  null;
  "TelephoneNo":  null;
  "Title":  null;
  "ValidNcheck":  null;
  "EffectiveDateStart":any;
  "UserName":null;

}*/


export class Admins
{
  /*"LoginId": null;
  "UserName": null;
  "UserId": null;
  "UserType": null;
  "BranchCode":null;
  "BranchName":null;
  "Status":null;
  "Status1": null;
  "ProductId": null;
  "MenuId": null;
  "BrokerCode": null;
  "UserMail": null;
  "AttachedUnderWriter":null;
  "AttachedBranch": null;
  "RegionCode": null;
  "AttachedRegion":null;
   "EffectiveDate":null;*/

    "AttachedBranchInfo": [
      {
        "AttachedBranchId": null;
      }
    ];
    "AttachedRegionInfo": [
      {
        "RegionCode": null;
      }
    ];
    "BranchCode": null;
    "BrokerInfo": [
      {
        "BrokerCode": null;
      }
    ];
    "Email": null;
    "LoginId": null;
    "MenuInfo": [
      {
        "MenuId":null;
      }
    ];
    "Mode": null;
    "Password": null;
    "ProductInfo": [
      {
        "ProductId":  null;
      }
    ];
    "RegionCode":  null;
    "Status":  null;
    "UnderWriterInfo": [
      {
        "UnderWriter":  null;
      }
    ];
    "UserName":  null;
    "UserType":  null;
    "EffectiveDate":null
  }
