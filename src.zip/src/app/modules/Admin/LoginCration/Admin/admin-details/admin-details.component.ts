import { OpenCoverComponent } from './../../../../open-cover/open-cover.component';
import { Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { Router } from '@angular/router';
import * as Mydatas from '../../../../../app-config.json';
import { MastersService } from '../../../Masters/masters.service';
import { FormGroup } from '@angular/forms';
import { DatePipe } from '@angular/common';
import { NbComponentStatus, NbGlobalPhysicalPosition, NbToastrService } from '@nebular/theme';
import { Admins } from './AdminModel';
import { AdminReferralService } from '../../../../admin-referral/admin-referral.service';


@Component({
  selector: 'app-details-list',
  templateUrl: './admin-details.component.html',
  styleUrls: ['./admin-details.component.scss']
})
export class AdmindetailsComponent implements OnInit {
  public BrokerForm: FormGroup;
  branchValue:any;
  public min: Date = new Date();picker1;
  public AppConfig: any = (Mydatas as any).default;
 public ApiUrl1: any = this.AppConfig.ApiUrl1;

  public userList:any[]=[];
  public userDetails: any;
  public branchList:any []=[];
 public regionList:any[]=[];

  StatusList:any[]=[]; regionId:any;
  branchId:any;
  AttachedBranchList:any[]=[];

  UnderWriter: any;
  Products:any;
  EmailId:any;
  Status:any;
  AttachedBranch:any;
  ExcludedMenus:any;
  Brokers:any;
  adminData:any[]=[];
  columnHeader:any[]=[];
  AdminDetails: any;
  BranchCode: any;
  LoginId: any;
  productNameList:any[]=[];
  password:any;
  editSection=false;
  userType:any[]=[];
  Brok: any;
  value:any="View";
  EPassword: any;
  NPassword: any;


  constructor(private masterSer: MastersService,private datePipe:DatePipe,
    private toastrService:NbToastrService, private router:Router, private adminReferralService: AdminReferralService){
    this.userDetails = JSON.parse(sessionStorage.getItem('Userdetails'));
    this.AdminDetails = new Admins();

    this.onGetBranchList();
    this.onGetRegionList();
    //this.getEditAdminDetails();
    this.StatusList=[{"Code":"Y","CodeDesc":"Active"},
    {"Code":"N","CodeDesc":"DeActive"},
    {"Code":"D","CodeDesc":"Delete"},
    {"Code":"T","CodeDesc":"Lock"},
];

/*this.userList=[{"Code":"6","CodeDesc":"6"},
{"Code":"7","CodeDesc":"7"},
{"Code":"8","CodeDesc":"8"},
{"Code":"9","CodeDesc":"9"},
];*/
//this.userType=[{"Code":"admin","CodeDesc":"admin"}]

  }
  ngOnInit(): void {
    let AdminObj = JSON.parse(sessionStorage.getItem('editAdminId'));
    //let password =sessionStorage.removeItem("password");
    //let password=sessionStorage.getItem('password');
     this.BranchCode = AdminObj?.BranchCode;
     this.LoginId = AdminObj.LoginId;

    if(this.LoginId!=null && this.LoginId!=undefined){
      this.getEditAdminDetails();
      this.editSection=false;


    }

    else{
      this.AdminDetails = new Admins();
      this.BranchCode = AdminObj.BranchCode;
      this.AdminDetails.LoginId = AdminObj.LoginId;
      this.editSection=true;
      //if(this.CityDetails?.Status==null)  this.CityDetails.Status = 'Y';
    }
    this.onUserType()

  }
  ongetBack()
  {
    this.router.navigate(['/Marine/loginCreation/admin'])
  }
  onProceed(){

  }
  /*getExistingAdmin(){

    let ReqObj = {
       "BranchCode": this.branchValue
   }

    let urlLink = `${this.ApiUrl1}admin/getAdminList`;
 this.masterSer.onPostMethodSync(urlLink, ReqObj).subscribe(
   (data: any) => {
     if (data?.Message === 'Success') {
       console.log(data);
       this.columnHeader = [
         {key: 'S.No', display: 'S.No'},
         {key: 'LoginId', display: 'Login Id'},
         {key: 'UserName', display: 'User Name'},
         {key: 'UserType', display: 'User Type'},
         {key: 'Branch', display: 'Branch'},
        {key: 'EffectiveDate', display: 'Effective Date'},
         {key: 'Status', display: 'Status'},
         {
           key: 'actions',
           display: 'Edit',
           config: {
             isEdit: true,
           }
         }
       ];
       this.adminData = data?.Result;
     }
   }, (err) => { }
 );
}*/
getEditAdminDetails(){

  let ReqObj =  {
    "BranchCode": this.BranchCode,
    "LoginId": this.LoginId,

}
  let urlLink = `${this.ApiUrl1}admin/getAdminEditList`;
this.masterSer.onPostMethodSync(urlLink, ReqObj).subscribe(
  (data: any) => {
    console.log(data);
    let res:any = data;
    if(res.Result){
      this.AdminDetails = res.Result[0];
           this.Status= res.Result[0].Status;
           this.Brok=this.AdminDetails.BrokerCode
      this.onGetBranchList();
      this.CommaFormatted();
      this.BranchComma();
      this.UnderWriters();
      this.AttachedBranches(this.AdminDetails.AttachedRegion);
      if(this.AdminDetails){
        if(this.AdminDetails?.EffectiveDate!=null){

         this.AdminDetails.EffectiveDate = this.onDateFormatInEdit(this.AdminDetails?.EffectiveDate)
        }

        /*if(this.AdminDetails?.EffectiveDateEnd!=null){
          this.AdminDetails.EffectiveDateEnd = this.onDateFormatInEdit(this.AdminDetails?.EffectiveDateEnd)
        }*/
  
  


      }
    }
    console.log("Final Admin Class",this.AdminDetails);
  },
  (err) => { },
);
}
onDateFormatInEdit(date) {
  console.log(date);
  if (date) {
    let format = date.split('-');
    if(format.length >1){
      var NewDate = new Date(new Date(format[0], format[1], format[2]));
      NewDate.setMonth(NewDate.getMonth() - 1);
      return NewDate;
    }
    else{
      format = date.split('/');
      if(format.length >1){
        var NewDate = new Date(new Date(format[2], format[1], format[0]));
        NewDate.setMonth(NewDate.getMonth() - 1);
        return NewDate;
      }
    }

  }
}
onGetBranchList() {
  const urlLink = `${this.ApiUrl1}login/getBranchDetail`;
  const reqData = {
    'RegionCode': '01',
  };
  this.adminReferralService.onPostMethodSync(urlLink, reqData).subscribe(
    (data: any) => {
      console.log(data);
      this.branchList = data || [];
      this.onGetRegionList();
    },
    (err) => { },
  );
}
onGetRegionList() {
  const urlLink = `${this.ApiUrl1}admin/region/list`;
  const reqData = {
    "RegionCode": "01"
  };
  this.adminReferralService.onPostMethodSync(urlLink, reqData).subscribe(
    (data: any) => {
      console.log(data);
      this.regionList = data?.Result || [];
     
      this.onGetProductList();
      this.onGetUnderwriter();
    },
    (err) => { },
  );
}

onGetProductList() {
  const urlLink = `${this.ApiUrl1}opencover/dropdown/referral/quoteproduct`;
  const reqData = {
    "LoginId": this.LoginId,
    "BranchCode": this.BranchCode
  };
  this.adminReferralService.onPostMethodSync(urlLink, reqData).subscribe(
    (data: any) => {
      console.log(data);
      this.productNameList = data?.Result?.ProductionDetails || [];
    },
    (err) => { },
  );
}


onUserType() {
  const urlLink = `${this.ApiUrl1}admin/getAdminUserTypeList`;
  const reqData = {
    "ApplicationId": "2",
    "BranchCode": this.BranchCode
  };
  this.adminReferralService.onPostMethodSync(urlLink, reqData).subscribe(
    (data: any) => {
      console.log(data);
      this.userType= data?.Result|| [];
    },
    (err) => { },
  );
}

onGetUnderwriter() {
  const urlLink = `${this.ApiUrl1}admin/getUnderWriterGradeList`;
  // const reqData = {
  //   "LoginId": this.LoginId,
  //   "BranchCode": this.BranchCode
  // };
  this.adminReferralService.onGetMethodSync(urlLink).subscribe(
    (data: any) => {
      console.log(data);
      this.userList = data?.Result || [];
    },
    (err) => { },
  );
}
onSaveAdmin() {

  console.log('UnderWriter', this.AdminDetails.UnderWriter)

  let uwList= []; 
  if(this.AdminDetails.AttachedUnderWriter.length!=0){
    let i=0
    for(let uw of this.AdminDetails.AttachedUnderWriter){
      let entry = {"UnderWriter":uw}
      uwList.push(entry);
      i++;
      if(i==this.AdminDetails.AttachedUnderWriter.length) this.region(uwList);
    }
   
  }
  else this.region(uwList)

  
}

region(uwList){
  let RegionList= [];
  if(this.AdminDetails.AttachedRegion.length!=0){
    let i=0;
      for(let u of this.AdminDetails.AttachedRegion){      
      let entryRegion={"RegionCode":u}    
      RegionList.push(entryRegion);
      i++;
      if(i==this.AdminDetails.AttachedRegion.length) this.AttachedBranchFinal(uwList,RegionList);
    }
  
  }
  else this.AttachedBranchFinal(uwList,RegionList)
}
changeRegion(){

  let uwList=[];
     console.log('hhh',this.AdminDetails.AttachedRegion)
  if(this.AdminDetails.AttachedRegion.length!=0){
    let i=0;
    for(let uw of this.AdminDetails.AttachedRegion){

      console.log('ueeee',uw)
      let entry = {"RegionCode":uw}
      uwList.push(entry);
      console.log('uuuuuu',uwList)
      i++;
      if(i==this.AdminDetails.AttachedRegion.length) this.AttachedBranches(uwList);
    }
  }
  //else this.AttachedBranches(uwList)

}

AttachedBranchFinal(uwList,RegionList){
  let BranchList= [];
  if(this.AdminDetails.AttachedBranch.length!=0){
    let i=0;
      for(let u of this.AdminDetails.AttachedBranch){      
      let entryRegion={"AttachedBranchId":u}    
      BranchList.push(entryRegion);
      i++;
      if(i==this.AdminDetails.AttachedBranch.length) this.onFinalSubmit(uwList,RegionList,BranchList);
    }
  
  }
  else this.onFinalSubmit(uwList,RegionList,BranchList)
}

AttachedBranches(region){
  let ReqObj = 
  {
    "AgencyCode": "",
  "RegionCodeInfo":region 
}
  this.masterSer.onPostMethodSync(`${this.ApiUrl1}admin/getAttachedBranchDetails`, ReqObj).subscribe(
    (data: any) => {
      console.log('ssssssss',data);
      this.AttachedBranchList= data || [];
    }
  )

}

/*onregion(){
  console.log('UnderWriter', this.AdminDetails.UnderWriter)

  let RegionList= [];
  if(this.AdminDetails.RegionCode.length!=0){
    let i=0;
    for(let uw of this.AdminDetails.RegionCode){
      let entry = {"RegionCode":uw}
      RegionList.push(entry);
      i++;
      if(i==this.AdminDetails.UnderWriter.length) this.onFinalSubmit();
    }
  }
  else this.onFinalSubmit(uwList)
}*/

CommaFormatted() {
  // format number

 /*let region=this.AdminDetails.AttachedRegion
if(region.includes(',')){ this.AdminDetails.AttachedRegion =region.replace(/,/g, '') }
  else this.AdminDetails.AttachedRegion = region
  /*if (this.AdminDetails.AttachedRegion) {
   this.AdminDetails.AttachedRegion= this.AdminDetails.AttachedRegion.replace(/\D/g, "")
     .replace(/\B(?=(\d{3})+(?!\d))/g, ",");
  }*/
  var str = this.AdminDetails.AttachedRegion;
this.AdminDetails.AttachedRegion= str.split(',');
this.AdminDetails.AttachedRegion = this.AdminDetails.AttachedRegion.filter(item => item);

// for(var i = 0; i < this.AdminDetails.AttachedRegion.length; i++)
// {
//    //console.log(this.AdminDetails.AttachedRegion[i]);
// }
  console.log('kk',this.AdminDetails.AttachedRegion)
}

BranchComma(){
  var str = this.AdminDetails.AttachedBranch;
this.AdminDetails.AttachedBranch= str.split(',');
this.AdminDetails.AttachedBranch = this.AdminDetails.AttachedBranch.filter(item => item);

// for(var i = 0; i < this.AdminDetails.AttachedBranch.length; i++)
// {
//    //console.log(this.AdminDetails.AttachedRegion[i]);
// }
  console.log('BBB',this.AdminDetails.AttachedBranch)
}

UnderWriters(){
  var str = this.AdminDetails.AttachedUnderWriter;
  this.AdminDetails.AttachedUnderWriter= str.split(',');
  
  /*for(var i = 0; i < this.AdminDetails.AttachedUnderWriter.length; i++)
  {
     //console.log(this.AdminDetails.AttachedRegion[i]);
  }*/
  this.AdminDetails.AttachedUnderWriter = this.AdminDetails.AttachedUnderWriter.filter(item => item);
  //var sparseArray = this.AdminDetails.AttachedUnderWriter;
  //this.AdminDetails.AttachedUnderWriter= sparseArray.filter(function () { return true });

    console.log('BBB',this.AdminDetails.AttachedUnderWriter)
}
onFinalSubmit(uwList,RegionList,BranchList){

  
  let ReqObj = {

    "AttachedBranchInfo": BranchList,
    "AttachedRegionInfo": RegionList,
    "BranchCode": this.BranchCode,
    "BrokerInfo": [
      {
        "BrokerCode":this.Brok
      }
      
    ],
    "Email":  this.AdminDetails.UserMail,
    "LoginId":  this.AdminDetails.LoginId,
    "MenuInfo": [
      {
        "MenuId":  this.AdminDetails.MenuId,
      }
    ],
    "Mode":  this.AdminDetails.Mode,
    "Password":  this.password,
    "ProductInfo": [
      {
        "ProductId":  this.AdminDetails.ProductId,
      }
    ],
    "RegionCode":  this.AdminDetails.RegionCode,
    "Status":  this.Status,
    "UnderWriterInfo": uwList,
    "UserName":  this.AdminDetails.UserName,
    "UserType":  this.AdminDetails.UserType,
    "EffectiveDate":this.AdminDetails.EffectiveDate
  }

let urlLink = `${this.ApiUrl1}admin/NewAdminInsert`;

if (ReqObj.EffectiveDate != '' && ReqObj.EffectiveDate != null && ReqObj.EffectiveDate != undefined) {
  ReqObj['EffectiveDate'] =  this.datePipe.transform(ReqObj.EffectiveDate, "dd/MM/yyyy")
}
else{
  ReqObj['EffectiveDate'] = "";
}
this.masterSer.onPostMethodSync(urlLink, ReqObj).subscribe(
  (data: any) => {
      console.log(data);
      let res:any=data;
      if(data.Result){
        let type: NbComponentStatus = 'success';
              const config = {
                status: type,
                destroyByClick: true,
                duration: 4000,
                hasIcon: true,
                position: NbGlobalPhysicalPosition.TOP_RIGHT,
                preventDuplicates: false,
              };
              this.toastrService.show(
                'Admin Details Inserted/Updated Successfully',
                'Admin Details',
                config);
                this.router.navigate(['/Marine/loginCreation/admin'])
                //this.router.navigate(['/Admin/countryMaster/cityList'])

      }
      else if(data.ErrorMessage){
          if(res.ErrorMessage){
            for(let entry of res.ErrorMessage){
              let type: NbComponentStatus = 'danger';
              const config = {
                status: type,
                destroyByClick: true,
                duration: 4000,
                hasIcon: true,
                position: NbGlobalPhysicalPosition.TOP_RIGHT,
                preventDuplicates: false,
              };
              this.toastrService.show(
                entry.Field,
                entry.Message,
                config);
            }
            console.log("Error Iterate",data.ErrorMessage)
            //this.loginService.errorService(data.ErrorMessage);
          }
      }
    },
    (err) => { },
  );
}

onRedirect(value){
  this.value=value;
  if(value == 'View'){

  }
  else if(value == 'ChangePassword'){
  }

}


ChangePassword(){
  const urlLink = `${this.ApiUrl1}admin/IssuerChangePassword`;
  const reqData = {
    "LoginId":this.LoginId,
   "Password": this.EPassword,
   "RePassword": this.NPassword
  };
  this.adminReferralService.onPostMethodSync(urlLink, reqData).subscribe(
    (data: any) => {
      console.log("Change Password Done Successfully");
     
    },
    (err) => { },
  );
}
Back(){
  this.value="View"
}
}

